import { Component } from 'angular/core';
@Component({
  selector: 'my-app',
  templateUrl: 'app/frontpage/frontpage.component.html',
  styleUrls: ['app/frontpage/frontpage.component.css']
})
export class ProductPageComponent {
  addeditemArray =[];
haha(event){
  this.addeditemArray.push(event);
  console.log(event);
}