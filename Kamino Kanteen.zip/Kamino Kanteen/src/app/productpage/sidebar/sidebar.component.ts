import { Component } from '@angular/core';

@Component({
  selector: 'sd-bar',
  templateUrl:'app/productpage/sidebar/sidebar.component.html',
  styleUrls:['app/productpage/sidebar/sidebar.component.css']
})

export class SidebarComponent{}