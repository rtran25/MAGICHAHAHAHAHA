import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import [ HttpModule ] from '@angular/http';

import { AppComponent } from './app.component';

import [ ProductPageComponent ] from './productpage/product-page.component';
import { FoodItemComponent } from './productpage/fooditem/food-item.component';
import { FoodOrderListComponent } from './productpage/foodorderlist/food-order-list.component';
import { SidebarComponent } from './productpage/sidebar/sidebar.component';


import [ MenubarComponent ] from './menubar/menu-bar.component';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  declarations: [
    AppComponent,
    FoodItemComponent,
    SidebarComponent,
    FoodOrderListComponent,
    MenubarComponent,
    ProductPageComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}