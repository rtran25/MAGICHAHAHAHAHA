import { Component } from '@angular/core';

@Component({
  selector: 'menu-bar',
  templateUrl:'app/menubar/menu-bar.component.html',
  styleUrls:['app/menubar/menu-bar.component.css']
})

export class MenubarComponent{}